
Author: 
Richard Xia (Student No: 101007519)
Ibrahim Faizullah (101011171)

#============================================
#Build 
#============================================
>make clean
>make
>./mytunes
mytunes> .help
CMD or .quit: .log start
CMD or .quit: .log start_both
CMD or .quit: .read insert_beatles_tracks_rev1.txt // this is done in program automatically
CMD or .quit: .read Part2TestScript.txt
CMD or .quit: .log stop
CMD or .quit: .log save test_result.txt
CMD or .quit: .quit

New functionality of Part I:
    // follower clones a playlist from leader and follow tthe change of leader
    follow -u follower_userid -p playlist_name -f leader_userid
    // follower stops following playlist from leader    
    follow -u follower_userid -p playlist_name -f stop

See the functionality of Part II below.

#============================================
#Part II Optional:
#Scenario #2:
#[Description]
#============================================
After part I is implemented, the musicians tested the functionaity and they satisify the design overall. 
The feedback is:
1) The leader and follower information is not availale in show functions: "show users" or "show users -u user_id". 
2) There is no distuguish that 
    - a playlist (or setlist) is neither leader or follower.
    - or a playlist (or setlist) is a leader or follower.

They want that the existing show functions, "show users" or "show users -u user_id", 
are enhanced to provide the playlist (setlist): 
- In leader's playlist/setlist, a list of followers should be displayed.
- In follower's playlist/setlist, the leader information should be available.
- When follower stopped to follow, the information should be available in show command.
- When leader's playlist is deleted, the ex-follower should be displayed as "stop follow" as well. 

"leader: followed by ajones, fjones" 
"follower: lead by cindy"
"no follower"

#============================================
# Scenario #2:
#### Functional and System Requirements for Part II ####
#============================================
FR4.2.1) The application should provide followers information 
       in show command to a leader's playlist/setlist.
       In leader's playlist/setlist, a list of followers should be displayed.
       In "show users" , or "show users -u user_id", 
	   playlist information should include a list of followers.
	   For example:
       <playlist name> [Leader: cindy ; followers: ajones fjones ]
	   
FR4.2.2) The application should provide leader information 
       in show command to a follower's playlist/setlist.
	   In follower's playlist/setlist, leader should be displayed.
       In "show users" , or "how users -u user_id", 
	   follower's playlist information should include leader.
	   For example:
	   <playlist name> [following leader: cindy ] 

FR4.2.3) When a follower stops follow, it should be displayed as: 
       <playlist name> [stop follow]
	   
FR4.2.4) When leader's playlist is deleted, the ex-follower should be 
	   displayed as "stop follow" as well. 
	   <playlist name> [stop follow]
	   
FR4.2.5) If no leader and follower's role is specified, it should be displyed as: 
       <playlist name> [lead/follow: N/A]

FR4.2.6) The information should be provided in "show users" and "show users -u user_id".

SR4.2.7) The functionality of part I should not be changed when functionality of part II is added. 

SR4.2.8) You MUST provide a Part II testing script of commands that shows all of the features 
         you have implemented are working.
		 The script name should be Part2TestScript.txt.

#============================================
###### File structure 
#============================================

#### code base ####
Coding is based on our implementation of assignment 3. 
Please refer the assignment 3 submission in culearning.
The description files are included for reference to assignmen 3:
COMP2404A_Assignment3_README.txt and COMP2404A_A3_UML.pdf.


#============================================
####Source code files####
# Base file from assignment 4: 
#============================================

# Testing script for part II scenario:
Part2TestScript.txt
Verify functionality of part II scenario

################################
##### new soure code files #####
################################
// Playlist's access class to LeadSetList or FollowSetList
// Each Playlist has a SetListRole which has three types: LEADER, FOLLOWER and NONE.
// SetListRole maintances LeadSetList or FollowSetList, and provide the access to them.
setlistrole.h
setlistrole.cpp 

// The LeadSetList class needs to be a subject in the subject-observer pattern. 
// That is, it will have to inherit from the Subject class
// The observers will be notified when the playlist of LeadSetList is changed. 
// ie add or delete Track. or the playlist of LeadSetList itself is deleted.
leadsetlist.h
leadsetlist.cpp

// The FollowSetList class needs to be observers. That is, inherit from the Observer class.
// The FollowSetList objects will have to attach() to their subject (ie LeadSetList) and 
// later dettach() once they have been executed. 
// The action objects should attach to their subject when they are first created 
// (i.e. in their constructors).
// FollowSetList (observer) implements update() method to react to 
// the change in their subject's change of playlist, or the playlist of subject is deleted.
followsetlist.h
followsetlist.cpp

// From tutorial 8: Gamma et al Observer Pattern
// A Subject and Observer superclass is provided for you which should not need to be modified.
subject.h
observer.h 
arraylist.h

################################
### changed soure code files ###
################################

playlist.h
playlist.cpp
// playlist is updated to access SetListRole which maintances 
// LeadSetList or FollowSetList, and provide the access to them.
// New functions to Playlist:
  SetListRole* getSetListRole() {return setListRole_p;};
  bool setLeadSetListRole();
  bool setFollowSetListRole(LeadSetList* otherLeadSetList_p);
  void replaceTrack(vector<Track*>& newTracks);
  void setUser(User* user_p) {this->user_p = user_p;};
  User* getUser() {return user_p;};

mytune_database.h
mytune_database.cpp
// New functions to MyTuneDataBase class:
  void executeCMDFOLLOW(Command cmd);
  void executeFollowSetList(Command cmd);
  void executeFollowSetListStop(Command cmd);

################################
#Base files from assignment 3: 
################################

myturnscollection.h:  // new class: Template-based Refactoring of the Application Containers

myturnelement.h:      // new class: abstract class which will be inherited by  
	              //            myturn database elements: Song, Recording, Track, User, Playlist

id.cpp // new class: uniformed protocol for Id (string or int Id) 
id.h   // new class: uniformed protocol for Id (string or int Id) 


mytune_database.cpp // new class: refatorring from mytunes.cpp
mytune_database.h   // new class: refatorring from mytunes.h
                   The data model and database is implemented in MyTuneDataBase.
                   In the new design, refactorring MyTuneDataBase into singleton class, 
                   and allows multiple front-end clients to access MyTuneDataBase. e.g 

                   MyTuneDataBase::getInstance()->executeCMDADD(cmd);
                   MyTuneDataBase::getInstance()->executeCMDDELETE(cmd);
                   MyTuneDataBase::getInstance()->executeCMDSHOW(cmd, view);

mytunes.cpp  // refactorred class: The database is implemented in MyTuneDataBase.
mytunes.h    // refactorred class: The database is implemented in MyTuneDataBase.

The following classs are refactorred:
   It inherits from abstract MytuneElement class
   It implemented uniformed protocol of Id (string or int Id)
   It implemented  getElementDisplayName() so Templated-based collection could display ElementName. 

playlist.cpp 
playlist.h 
recording.cpp
recording.h
song.cpp
song.h
track.cpp
track.h
user.cpp
user.h

# unchanged files from 2404 course materials (2404A Assignment 2 answer code)
UI.cpp
UI.h
command.cpp
command.h
main.cpp
str_util.cpp
str_util.h

#
Makefile (mytunes is the exexable)

# this file
README.txt 

# CLI help context
help.txt

#
COMP2404A_A3_UML.pdf
#
Provide a A3 Part II Analysis document in .pdf format that has the itemized explanations
and documentation asked for below. 
Submit this document file with your code files.

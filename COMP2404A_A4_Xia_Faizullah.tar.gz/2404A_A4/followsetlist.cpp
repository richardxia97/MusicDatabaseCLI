/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <string>
using namespace std;

#include "followsetlist.h"
#include "playlist.h"
#include "user.h"

FollowSetList::FollowSetList(Playlist* playlist_p, LeadSetList* leadSetList_p) {
  this->playlist_p = playlist_p;
  leadSetList_p->attach(*this);
  this->leadSetList_p = leadSetList_p;
  isStopFollow = false;
}

FollowSetList::FollowSetList(const FollowSetList & aFollowSetList){
	cout << "FollowSetList(const FollowSetList & aFollowSetList)" << endl;
	cout << "ERROR: FollowSetList(const FollowSetList & aFollowSetList) --should never run" << endl;
}

FollowSetList::~FollowSetList(){
	cout << "~FollowSetList(void)" << endl;
	stopFollow();
}

void FollowSetList::update(Subject * subject) {
  if (isStopFollow || leadSetList_p == NULL) {
    cout << "ERROR: update should not be called: stopFollow=true" << endl;
    return;
  }
  
  // lead set list is being deleted.
  if (leadSetList_p->isDeleteInProgress()) {
    stopFollow();
    return;
  }
  
  // sync up with LeadSetList
  playlist_p->replaceTrack((leadSetList_p->getPlaylist())->getTracks());
}

void FollowSetList::stopFollow() {
  if (leadSetList_p != NULL) {
    leadSetList_p->dettach(*this);
    this->leadSetList_p = NULL;
  }
  isStopFollow = true;
}

string FollowSetList::getDescription() { 
  string description = "";
  if (isStopFollow) {
    description = "[stop follow]";
  } else {
    description = "[following leader: "+ leadSetList_p->getPlaylist()->getUser()->getUserID() + " ]";
  }
  return description;
}

void FollowSetList::printOn(ostream & out) const {
  out << "FollowSetList: " << playlist_p->toString() << endl;
}


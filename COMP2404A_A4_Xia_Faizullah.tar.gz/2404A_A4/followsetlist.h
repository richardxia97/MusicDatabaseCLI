/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _FollowSetList_H
#define _FollowSetList_H

#include <ostream>
#include <string>
#include <vector>

#include "subject.h"
#include "observer.h"

class Playlist;
class LeadSetList;

class FollowSetList : public Observer {
    
  // The FollowSetList class needs to be observers. That is, inherit from the Observer class.
  // The FollowSetList objects will have to attach() to their subject (ie LeadSetList) and 
  // later dettach() once they have been executed. 
  // The action objects should attach to their subject when they are first created 
  // (i.e. in their constructors).
  // FollowSetList (observer) implements update() method to react to 
  // the change in their subject's change of playlist, or the playlist of subject is deleted.
  
	public:
	FollowSetList(Playlist* playlist_p, LeadSetList* leadSetList_p); 
	~FollowSetList(void);
	FollowSetList(const FollowSetList & aFollowSetList); 
	void update(Subject * subject); 
	void printOn(ostream & out) const;
	string getDescription();
	Playlist* getPlaylist() {return playlist_p;};
	void stopFollow();
	bool getStopFollow() {return isStopFollow;};
	
	private:
	Playlist* playlist_p;
	LeadSetList* leadSetList_p;
	bool isStopFollow;
};

inline ostream & operator<<(ostream & out, const FollowSetList & aFollowSetList) {
  aFollowSetList.printOn(out); 
  return out; 
}

#endif

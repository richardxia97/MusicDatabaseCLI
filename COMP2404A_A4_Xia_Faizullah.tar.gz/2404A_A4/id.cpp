/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <string>
using namespace std;

#include "id.h"

Id::Id()
{
  this->type = INT_BASED_ID;
  this->id = 0;
}

Id::Id(const string & idStr)
{
  this->type = STRING_BASED_ID;
  this->idStr = idStr;
}
Id::Id(int id) 
{
  this->type = INT_BASED_ID;
  this->id = id;
}

string Id::toString() const {
  if (type == INT_BASED_ID) 
  { 
    return std::to_string(id); 
  } else { 
    return idStr; 
  } 
}

Id::Id(const Id & anId) //hide copy constructor in private section
{
	this->type = anId.type;
  this->id = anId.id;
  this->idStr = anId.idStr;
}

bool Id::operator==(const Id & anId) {
  if (this->type != anId.type) {
    return false;
  }
  if (this->type == INT_BASED_ID) {
    return this->id == anId.id; 
  } else {
    return (this->idStr.compare(anId.idStr) == 0);
  }
}

ostream & operator<<(ostream & out, const Id & anId){
	out << anId.toString() << endl;
	return out;
}


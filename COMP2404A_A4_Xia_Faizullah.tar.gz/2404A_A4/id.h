/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */


#ifndef _ID_H
#define _ID_H

#include <ostream>
#include <string>

class Id {
	/*
	Generic Id.
	Id could either integer or string
	two constructors: int id or string id
	*/
	public:
  enum IdType {INT_BASED_ID, STRING_BASED_ID};
  Id(); // default constructor
  /*constructor for string id*/
	Id(const string & idStr);
	/*constructor for int id*/
	Id(int id); 
	~Id(void) {};
	bool operator==(const Id & anId);
	Id(const Id & anId);
  int getID() {return id; };
  string getIdStr() {return idStr;};
  string toString() const;
	
	private:
  IdType type;
	int id; //numeric id for uniformity with other model classes
	string idStr;
  
};

ostream & operator<<(ostream & out, const Id & anId);



#endif

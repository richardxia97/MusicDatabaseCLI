/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <string>
using namespace std;

#include "leadsetlist.h"
#include "followsetlist.h"
#include "playlist.h"
#include "user.h"

LeadSetList::LeadSetList(Playlist* playlist_p) {
  this->playlist_p = playlist_p;
  deleteInProgress = false;
}
/*
LeadSetList::LeadSetList(const LeadSetList & aLeadSetList){
	cout << "LeadSetList(const LeadSetList & aLeadSetList)" << endl;
	cout << "ERROR: LeadSetList(const LeadSetList & aLeadSetList) --should never run" << endl;
}
*/

LeadSetList::~LeadSetList(){
	//cout << "~LeadSetList(void)" << endl;
  // deallocate the dynamically allocated memory
}

void LeadSetList::notifyFollowers() {
  notify(); 
}

string LeadSetList::getDescription() { 
  string description = "[Leader: "+ getPlaylist()->getUser()->getUserID() + " ; followers: ";
  ArrayList<Observer> observers_copy = observers; //make copy to iterate over
 
  for(ArrayList<Observer>::iterator itr = observers_copy.begin(); itr != observers_copy.end(); itr++) {
     description += ((FollowSetList &) *itr).getPlaylist()->getUser()->getUserID();
     description += " ";
  } 
  description += " ]";
  return description;
}

void LeadSetList::printOn(ostream & out) const {
  out << "LeadSetList: playlist=" << playlist_p->toString() << endl;
 }

/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _LeadSetList_H
#define _LeadSetList_H

#include <ostream>
#include <string>
#include <vector>

#include "subject.h"

class Playlist;
class FollowSetList;
class LeadSetList : public Subject {
  
  // The LeadSetList class needs to be a subject in the subject-observer pattern. 
  // That is, it will have to inherit from the Subject class
  // The observers will be notified when the playlist of LeadSetList is changed. 
  // ie add or delete Track. or the playlist of LeadSetList itself is deleted.
  
	public:
	LeadSetList(Playlist* playlist_p); 
	~LeadSetList(void);
	Playlist* getPlaylist() {return playlist_p;};
	void notifyFollowers();
	void printOn(ostream & out) const;
	int getObserverSize() {return observers.size();};
	void setDeleteInProgress() {deleteInProgress=true;};
	int isDeleteInProgress() {return deleteInProgress;};
	string getDescription();
	private:
	Playlist* playlist_p;
	bool deleteInProgress;
	//LeadSetList(const LeadSetList & aLeadSetList); //hide copy constructor in private section
};

inline ostream & operator<<(ostream & out, const LeadSetList & aLeadSetList) {
  aLeadSetList.printOn(out);
  return out;
}

#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTuneDataBase Music Player            */
/*  Author:   Louis Nel                              */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     21-SEP-2017                            */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef MYTUNE_DATABASE_H
#define MYTUNE_DATABASE_H

#include <sstream>
using namespace std;
#include "UI.h"
#include "command.h"
#include "myturnscollection.h"
#include "song.h"
#include "recording.h"
#include "track.h"
#include "user.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * Database of Mytunes application.
 * 
 * Main interface to access
 * UML implementation of Songs, Recordings, Tracks and Users
 * 
 * This is implemented as a singleton class to ensure only 
 * one database which is accessed via front-end UI or applicaton thread 
 * (e.g multipe threads each running MyTurns).
 * 
 * 
 * The existing design couples application (MyTurns), UI, and database 
 * (collections of songs, recordings, tracks, users, and playlist). 
 * It allows only a single front applications to access database. 
 * ie. only one user can access application at the same time.
 * 
 * In the new design, refactorring DataBase into singleton class, and 
 * allows multiple front-end clients to access MyTuneDataBase. e.g 
 *    MyTuneDataBase::getInstance()->executeCMDADD(cmd);
 *    MyTuneDataBase::getInstance()->executeCMDDELETE(cmd);
 *    MyTuneDataBase::getInstance()->executeCMDSHOW(cmd, view);
 *    
 * This will decouple database from front-end application and UI to 
 * achieve scalability to support multipe client (ie. multiple application 
 * threads, UI) to access the same database.
 *    
 * E.g user cindy and ajones can access database through separate client 
 * interface (application  thread and UI) to show and modify their 
 * playlists, or add new songs, tracks.
 * 
 * Known limitation:
 * To support access database from multiple clients, thread synchronization 
 * will be required. It is not included in this refactorring assignment.
 */

class MyTuneDataBase
{
  public:   

    /* Static access method. */
    static MyTuneDataBase* getInstance();

    void executeCMDADD(Command cmd);
    void executeCMDDELETE(Command cmd);
    void executeCMDSHOW(Command cmd, UI view);
    void executeCMDFOLLOW(Command cmd);

  private:
    /* private constructor to implement singleton class*/
     MyTuneDataBase(); 
    /*static private data member: to implement singleton class*/
     static MyTuneDataBase* m_instance;


	 //Data Model
	 //available ID's for app assigned ID's
	 //These should only be used after database data has loaded
	int nextAvailableSongID;
	int nextAvailableRecordingID;
	int nextAvailableTrackID;
	//Data collections
  MyTurnsCollection<Song> songs;
  MyTurnsCollection<Recording> recordings;
  MyTurnsCollection<Track> tracks;
  MyTurnsCollection<User> users;

  void executeAddSong(Command cmd);
  void executeAddRecording(Command cmd);
  void executeAddTrack(Command cmd);
  void executeAddUser(Command cmd);
  void executeAddPlaylist(Command cmd);
  void executeAddPlaylistTrack(Command cmd);
  
  void executeDeleteRecording(Command cmd);
  void executeDeleteUser(Command cmd);
  void executeDeleteUserPlaylist(Command cmd);  
  void executeDeleteUserPlaylistTrack(Command cmd);
  void executeDeleteTrack(Command cmd); //cascading delete
  void executeDeleteSong(Command cmd);
  
  void executeFollowSetList(Command cmd);
  void executeFollowSetListStop(Command cmd);
   
};
#endif

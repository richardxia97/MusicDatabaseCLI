/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
using namespace std;
#include "str_util.h"
#include "mytunes.h"
#include "UI.h"
#include "command.h"

MyTunes::MyTunes():view(this)
{
}

void MyTunes::run()
{
	//start user interface
	view.run(); 

}
void MyTunes::executeCommand(Command cmd){

    //execute application (non UI shell) commands
    //These are the commands that affect the data model
    //or retrieve contents from the data model
	if(cmd.isCommand(CMD_ADD)) MyTuneDataBase::getInstance()->executeCMDADD(cmd);
	else if(cmd.isCommand(CMD_DELETE)) MyTuneDataBase::getInstance()->executeCMDDELETE(cmd);
	else if(cmd.isCommand(CMD_SHOW)) MyTuneDataBase::getInstance()->executeCMDSHOW(cmd, view);
	else if(cmd.isCommand(CMD_FOLLOW)) MyTuneDataBase::getInstance()->executeCMDFOLLOW(cmd);
}

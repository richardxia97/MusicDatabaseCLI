/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef MYTUNES_H
#define MYTUNES_H
#include <sstream>
using namespace std;
#include "UI.h"
#include "command.h"
#include "command.h"
#include "mytune_database.h"
/*
This is the main application class. in future, the application 
could be refactorred to support mullitple thread each running this application.

It has knowlege of the UI. 

The data model and database is implemented in MyTuneDataBase.
In the new design, refactorring MyTuneDataBase into singleton class, 
and allows multiple front-end clients to access MyTuneDataBase. e.g 

MyTuneDataBase::getInstance()->executeCMDADD(cmd);
MyTuneDataBase::getInstance()->executeCMDDELETE(cmd);
MyTuneDataBase::getInstance()->executeCMDSHOW(cmd, view);

*/

class MyTunes
{
  public:
    MyTunes();
    void run();
    void executeCommand(Command cmd);	
  private:
    UI view;	
};
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _MYTUNE_ELEMENT_H
#define _MYTUNE_ELEMENT_H

#include <string>
#include "id.h"

class MytuneElement {
	/*
	 * MytuneElement is an abstract class which will be inherited by  
	 * myturn database elements: Song, Recording, Track, User, Playlist
	 */
	public:
  virtual int getID() = 0; // numeric ID 
  virtual Id getUId() = 0; // uniformed id
  virtual string toString() const = 0;
  
	protected:
  int id; //numeric id for uniformity with other model classes
  Id uId; // uniformed id
};

#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _MYTURNSCOLLECTION_H
#define _MYTURNSCOLLECTION_H

#include <ostream>
#include <vector>
#include <string>
using namespace std;
#include "UI.h"
#include "id.h"

template <class T>
//template <typename T>

class MyTurnsCollection {
	/*
	 * Template-based Refactoring of the Application Containers
	 * MyTurnsCollection represents a collection of templated-based objects
	 * A MyTurnsCollection container OWNS the templated-based objects within it.
	 * If the container is destroyed it deletes the templated-based objects it contains
	 * If a templated-based is removed from the container the templated-based object is deleted from heap space.
	 */
	public:
	MyTurnsCollection() {};
	
	~MyTurnsCollection(void) 
	{
	  for(int i=0; i<collection.size(); i++)
	    delete collection[i]; //delete MyTurnsCollection in this container
	};

	T* findByUID(Id anID)
	{
	    for (typename vector<T*>::iterator it = collection.begin() ; it != collection.end(); ++it)
	    {
	      if((*it)->getUId() == anID) 
	      {
	        return *it;
	      }
	    }
	    return NULL;
	 };
	
	 string getElementDisplayName()
	 {
	   typename vector<T*>::iterator it = collection.begin();
	   return (*it)->getElementDisplayName();
	 };
	vector<T*> getCollection() {return collection;};
	
	void add(T& aT)
	{
	  collection.push_back(&aT);
	};
	
	void remove(T& aT) 
	{
	  typename vector<T*>::iterator index = findPosition(aT);
	  if(index != collection.end()) { 
	    T* theT = *index;
	    collection.erase(index);
	    delete theT; //free the memory of theT
	  }
	};
	
	void showOn(UI & view) 
	{
	  view.printOutput(getElementDisplayName());
	  for(int i=0; i<collection.size(); i++){    
	       view.printOutput((*collection[i]).toString());
	  }    
	};
	
	void showOn(UI & view, int memberID) 
	{
	  view.printOutput(getElementDisplayName());
	  T* t_p = findByUID(Id(memberID));
	  if( t_p != NULL)
	       view.printOutput(t_p->toString());
	};
	
	void showOn(UI & view, const string & memberID)
	{
	  view.printOutput(getElementDisplayName());
	  T* t_p = findByUID(Id(memberID));
	  if(t_p != NULL)
	       view.printOutput(t_p->toString());   
	};
	
	private:
	vector<T*> collection;
	typename vector<T*>::iterator findPosition(T& aT)
	{
	  for (typename vector<T*>::iterator it = collection.begin() ; it != collection.end(); ++it)
	    if(*it == &aT) return it;
	  return collection.end();
	}
};


#endif

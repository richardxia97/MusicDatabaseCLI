
Author: 
Richard Xia (Student No: 101007519)
Ibrahim Faizullah (101011171)

============================================
Build 
============================================
>g++ --version
g++ (OSE 4.9.2-2 20160202) 4.9.2
>make clean
>make
>./mytunes
mytunes> .help
CMD or .quit: .log start
CMD or .quit: .log start_both
CMD or .quit: .read insert_beatles_tracks_rev1.txt // this is done in program automatically
CMD or .quit: .read Part2TestScript.txt
CMD or .quit: .log stop
CMD or .quit: .log save test_result.txt
CMD or .quit: .quit

============================================
###### File structure 
============================================
#Source code files: 

myturnscollection.h:  // new class: Template-based Refactoring of the Application Containers

myturnelement.h:      // new class: abstract class which will be inherited by  
	              //            myturn database elements: Song, Recording, Track, User, Playlist

id.cpp // new class: uniformed protocol for Id (string or int Id) 
id.h   // new class: uniformed protocol for Id (string or int Id) 


mytune_database.cpp // new class: refatorring from mytunes.cpp
mytune_database.h   // new class: refatorring from mytunes.h
                   The data model and database is implemented in MyTuneDataBase.
                   In the new design, refactorring MyTuneDataBase into singleton class, 
                   and allows multiple front-end clients to access MyTuneDataBase. e.g 

                   MyTuneDataBase::getInstance()->executeCMDADD(cmd);
                   MyTuneDataBase::getInstance()->executeCMDDELETE(cmd);
                   MyTuneDataBase::getInstance()->executeCMDSHOW(cmd, view);

mytunes.cpp  // refactorred class: The database is implemented in MyTuneDataBase.
mytunes.h    // refactorred class: The database is implemented in MyTuneDataBase.

The following classs are refactorred:
   It inherits from abstract MytuneElement class
   It implemented uniformed protocol of Id (string or int Id)
   It implemented  getElementDisplayName() so Templated-based collection could display ElementName. 

playlist.cpp 
playlist.h 
recording.cpp
recording.h
song.cpp
song.h
track.cpp
track.h
user.cpp
user.h

# unchanged files from 2404 course materials (2404A Assignment 2 answer code)
UI.cpp
UI.h
command.cpp
command.h
main.cpp
str_util.cpp
str_util.h

#
Makefile (mytunes is the exexable)

# this file
README.txt 

# CLI help context
help.txt

# Regression Testing script
Part2TestScript.txt
illustrates that refactoring did not alter the intended behaviour of the code. 

#
COMP2404A_A3_UML.pdf
#
Provide a Part II Analysis document in .pdf format that has the itemized explanations
and documentation asked for below. 
Submit this document file with your code files.


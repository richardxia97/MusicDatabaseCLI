/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <string>
using namespace std;

#include "playlist.h"
	
Playlist::Playlist(const string & aPlaylistName){
	//cout << "Playlist(string&)" << endl;
	name = aPlaylistName;
	uId = Id(name);
	setListRole_p = new SetListRole(this);
	user_p = NULL;
}
Playlist::Playlist(const Playlist & aPlaylist){
	cout << "Playlist(const Playlist & aPlaylist)" << endl;
	cout << "ERROR: Playlist(const Playlist & aPlaylist) --should never run" << endl;
}

Playlist::~Playlist(){
	//cout << "~Playlist(void)" << endl;
  
  if (setListRole_p->getSetListRoleType() == SetListRole::LEADER) {
    // if playlist has leader role, set to DeleteInProgress
    // notify the followers to update
    // the followers will deference from the leader
    setListRole_p->getLeadSetList()->setDeleteInProgress();
    setListRole_p->getLeadSetList()->notifyFollowers();
  } 
  
  delete setListRole_p;
}
int Playlist::getID(){return -1;}
string Playlist::getName(){return name;}

Id Playlist::getUId() {return uId;} // uniformed id

vector<Track*> & Playlist::getTracks(){return tracks;}

vector<Track*>::iterator Playlist::findPosition(Track & aTrack){
	for (vector<Track*>::iterator itr = tracks.begin() ; itr != tracks.end(); ++itr)
		if(*itr == &aTrack) return itr;
	return tracks.end();
}

void Playlist::addTrack(Track & aTrack){
  
  // not allow to add track if the player list is following a leader playlist
  if (setListRole_p->getSetListRoleType() == SetListRole::FOLLOWER &&
      !(setListRole_p->getFollowSetList())->getStopFollow()) {
    cout << "Follower: not allow to add track"  << endl;
    return;
  } 
  
	//add track if it does not already exist
	vector<Track*>::iterator itr = findPosition(aTrack);
	if(itr == tracks.end()) {
		tracks.push_back(&aTrack);
	}
	
	// if playlist has leader role, notify the followers to update
	if (setListRole_p->getSetListRoleType() == SetListRole::LEADER) {
	  setListRole_p->getLeadSetList()->notifyFollowers();
	} 
}

void Playlist::removeTrack(Track & aTrack){
  
  // not allow to add track if the player list is following a leader playlist
  if (setListRole_p->getSetListRoleType() == SetListRole::FOLLOWER &&
      !(setListRole_p->getFollowSetList())->getStopFollow()) {
    cout << "Follower: not allow to remove track"  << endl;
    return;
  } 

	vector<Track*>::iterator itr = findPosition(aTrack);
	if(itr != tracks.end()) {
		tracks.erase(itr);
	}
	
  // if playlist has leader role, notify the followers to update
  if (setListRole_p->getSetListRoleType() == SetListRole::LEADER) {
    setListRole_p->getLeadSetList()->notifyFollowers();
  } 
}

void Playlist::replaceTrack(vector<Track*>& newTracks){
  vector<Track*>::iterator itr = tracks.begin(); 
  while(itr != tracks.end()) {
    itr = tracks.erase(itr);
  }
    
  vector<Track*>::iterator itr2 = newTracks.begin(); 
  while(itr2 != newTracks.end()) {
    tracks.push_back(*itr2);
    itr2++;
  }
}

string Playlist::toString()const {
	string indent = "     ";
	string s;
	s.append(name);
	s.append(" " +setListRole_p->getSetListDesciption());  // set list description: lead/follow/NA
	s.append("\n");
	s.append(indent + indent + "Playlist Tracks:\n");
	for (vector<Track*>::size_type i = 0 ; i < tracks.size(); i++){
		   s.append(indent + indent + to_string(i) + " " + (tracks[i])->toString() + "\n");
	}
	
	return s;
}

bool Playlist::setLeadSetListRole() {
  return setListRole_p->setLeadSetListRole();
}

bool Playlist::setFollowSetListRole(LeadSetList* otherLeadSetList_p) {
  return setListRole_p->setFollowSetListRole(otherLeadSetList_p);
}

ostream & operator<<(ostream & out, const Playlist & aPlaylist){
	out << aPlaylist.toString() << endl;
	return out;
}

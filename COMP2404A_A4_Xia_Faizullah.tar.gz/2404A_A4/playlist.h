/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _Playlist_H
#define _Playlist_H

#include <ostream>
#include <string>
#include <vector>

//#include "playlist.h"
#include "track.h"
#include "setlistrole.h"

class User;
class LeadSetList;
class FollowSetList;
class Playlist : public MytuneElement {
	/*
	Playlist represents an user playlist of tracks.
	*/
	public:
	Playlist(const string & aPlaylistName); 
	~Playlist(void);
   int getID();
	Id getUId(); // uniformed id
	string getName();
	static string getElementDisplayName() {return "Playlist";};
	void removeTrack(Track & aTrack);
	void addTrack(Track & aTrack);
	vector<Track*> & getTracks();
  string toString() const;
  SetListRole* getSetListRole() {return setListRole_p;};
  bool setLeadSetListRole();
  bool setFollowSetListRole(LeadSetList* otherLeadSetList_p);
  void replaceTrack(vector<Track*>& newTracks);
  void setUser(User* user_p) {this->user_p = user_p;};
  User* getUser() {return user_p;};
  
	private:
	string name;
	vector<Track*> tracks;	
	vector<Track*>::iterator findPosition(Track & aTrack);
	Playlist(const Playlist & aPlaylist); //hide copy constructor in private section
	SetListRole* setListRole_p;
	User* user_p;
};

ostream & operator<<(ostream & out, const Playlist & aPlaylist);

#endif
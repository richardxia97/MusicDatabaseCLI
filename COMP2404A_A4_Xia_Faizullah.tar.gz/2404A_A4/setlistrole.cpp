/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
using namespace std;

#include "setlistrole.h"
#include "playlist.h"
	
SetListRole::SetListRole() {
  roleType = NONE;
	playlist_p = NULL;
  leadSetList_p = NULL;
  followSetList_p = NULL;
}

SetListRole::SetListRole(Playlist *playlist_p) {
	this->playlist_p = playlist_p;
  leadSetList_p = NULL;
  followSetList_p = NULL;
	roleType = NONE;
}



/*
SetListRole::SetListRole(const SetListRole & aSetListRole){
	cout << "SetListRole(const SetListRole & aSetListRole)" << endl;
	cout << "ERROR: SetListRole(const SetListRole & aSetListRole) --should never run" << endl;
}
*/

SetListRole::~SetListRole(){
	//cout << "~SetListRole(void)" << endl;
  if (leadSetList_p != NULL) {
    delete leadSetList_p;
  }
  
  if (followSetList_p != NULL) {
    delete followSetList_p;
  }
}


bool SetListRole::setLeadSetListRole() {
  if (roleType == NONE && playlist_p != NULL) {
    roleType = LEADER;
    leadSetList_p = new LeadSetList(playlist_p);
    return true;
  }
  return false;
}

bool SetListRole::setFollowSetListRole(LeadSetList* otherLeadSetList_p) {
  if (roleType == NONE && playlist_p != NULL) {
    roleType = FOLLOWER;
    followSetList_p = new FollowSetList(playlist_p, otherLeadSetList_p);
    return true;
  }
  return false;
}

string SetListRole::getSetListDesciption() {
  string description = "";
  if (getSetListRoleType() == SetListRole::LEADER) {
    if (leadSetList_p != NULL) {
       description = leadSetList_p->getDescription();
    }
  } else if (getSetListRoleType() == SetListRole::FOLLOWER) {
    if (followSetList_p != NULL) {
       description = followSetList_p->getDescription();
    }
  } else if (getSetListRoleType() == SetListRole::NONE) {
    description = "[lead/follow: N/A]";  
  } 
  return description;
}
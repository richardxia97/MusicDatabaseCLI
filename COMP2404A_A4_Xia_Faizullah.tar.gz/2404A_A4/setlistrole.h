/* * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                   */
/*  Program:  MyTunes Music Player                   */
/*  Contributor:   Louis Nel                         */
/*                 Richard Xia (101007519)           */
/*                 Ibrahim Faizullah (101011171)     */
/*  Date:     NOV-2017                               */
/*                                                   */
/*  (c) 2017 Louis Nel                               */
/*  All rights reserved.  Distribution and           */
/*  reposting, in part or in whole, requires         */
/*  written consent of the author.                   */
/*                                                   */
/*  COMP 2404 students may reuse this content for    */ 
/*  their course assignments without seeking consent */
/* * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _SetListRole_H
#define _SetListRole_H

#include <ostream>
#include <string>

#include "leadsetlist.h"
#include "followsetlist.h"

class Playlist;
class SetListRole {
  
	/*
	 *SetListRole represents the role of an user playlist/setlist.
	 *Each playlist/setlist has a SetListRole.
	 *
	 *A SetListRole could be:
	 *1) Leader: when the change is made in its playlist, its followers 
	 *           are notify to get the change and update the playlist.
	 *           If track is added or deleted in the leader's playlist,
	 *           it will be reflected in the follower's playlist.
	 *           If leader's playlist is deleted, its followered will be
	 *           notified to deference with leader.
	 *2) Follower: a follower (of a playlis/setlist) could be stopped to 
	 *           follow. when stop follow, its playlist behaves a default
	 *           playlist without lead/follow relation ship.
	 *           playlist could be updated independently.
	 *3) No Lead/Follow relationship:
	 *           this is the default role of SetListRole for playlist.
	 *
	 * 
	 * The implementation of the follow command is based on the Gamma Observer
	 * Pattern. Subject and Observer abstract superclasses are used. 
	 * methods with names that correspond as closely as possible 
	 * with the method protocol of the Gamma observer pattern.
	 * 
	 */
	public:
	enum SetListRoleType {NONE, LEADER, FOLLOWER};
	SetListRole(); // default constructor
	SetListRole(Playlist *playlist_p);
	~SetListRole(void);
	SetListRoleType getSetListRoleType() {return roleType; };
	LeadSetList* getLeadSetList() {return leadSetList_p; };
	FollowSetList* getFollowSetList() {return followSetList_p;};
	bool setLeadSetListRole();
	bool setFollowSetListRole(LeadSetList* otherLeadSetList_p);
	string getSetListDesciption();
	
	private:
	SetListRoleType roleType;
	Playlist* playlist_p;
	LeadSetList* leadSetList_p;
	FollowSetList* followSetList_p;
	//SetListRole(const SetListRole & aSetListRole); //hide copy constructor in private section
};

//ostream & operator<<(ostream & out, const SetListRole & aSetListRole);

#endif
